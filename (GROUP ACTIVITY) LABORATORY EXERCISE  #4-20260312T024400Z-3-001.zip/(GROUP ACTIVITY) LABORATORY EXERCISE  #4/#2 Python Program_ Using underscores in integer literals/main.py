# Using underscores for better readability
num1 = 25000000 # wihout underscores
num2 = 25_000_000 # with underscores

print(num1)
print(num2)