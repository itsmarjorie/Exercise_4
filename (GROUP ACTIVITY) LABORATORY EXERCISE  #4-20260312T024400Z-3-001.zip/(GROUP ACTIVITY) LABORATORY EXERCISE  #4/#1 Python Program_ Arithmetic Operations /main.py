# Arithmetic Operations for int, float, and complex

# Integer numbers
a_int = 10
b_int = 6

print("Integer Operations:")
print("Addition:", a_int + b_int)
print("Subtraction:", a_int - b_int)
print("Multiplication:", a_int * b_int)
print("Division:", a_int / b_int)
print("Modulus:", a_int % b_int)
print("Exponent:", a_int ** b_int)
print()

# Float numbers
a_float = 10.5
b_float = 3.2

print("Float Operations:")
print("Addition:", a_float + b_float)
print("Subtraction:", a_float - b_float)
print("Multiplication:", a_float * b_float)
print("Division:", a_float / b_float)
print("Modulus:", a_float % b_float)
print("Exponent:", a_float ** b_float)
print()

# Complex numbers
a_complex = 2 + 3j
b_complex = 1 + 2j

print("Complex Operations:")
print("Addition:", a_complex + b_complex)
print("Subtraction:", a_complex - b_complex)
print("Multiplication:", a_complex * b_complex)
print("Division:", a_complex / b_complex)
# Note: Modulus and exponentiation are not typically used with complex in the same way